/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : psy

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2023-07-02 23:38:52
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for consultation
-- ----------------------------
DROP TABLE IF EXISTS `consultation`;
CREATE TABLE `consultation` (
  `con_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stu_id` bigint(20) DEFAULT NULL,
  `stu_name` varchar(255) DEFAULT NULL,
  `t_id` bigint(20) DEFAULT NULL COMMENT '咨询师id',
  `t_name` varchar(255) DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL COMMENT '表示是否结案，已结案则置为1',
  `date` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`con_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10888891 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of consultation
-- ----------------------------
INSERT INTO `consultation` VALUES ('1011112', '10227722', 'asd', '20201415', 'jkhjk', '1', null, null);
INSERT INTO `consultation` VALUES ('10111111', '10222222', 'aaa', '20201415', 'bbb', '0', null, null);
INSERT INTO `consultation` VALUES ('10841651', '10541236', 'dffg', '20201415', 'hjk', '0', null, null);
INSERT INTO `consultation` VALUES ('10888888', '10666666', 'aaasdf', '10333333', 'wrr', '0', null, null);
INSERT INTO `consultation` VALUES ('10888889', '123456', null, '20204563', null, '1', '周五', '14:00-16:00');
INSERT INTO `consultation` VALUES ('10888890', '20201181', '111', '20204563', '王八', '1', '周五', '14:00-16:00');

-- ----------------------------
-- Table structure for con_record
-- ----------------------------
DROP TABLE IF EXISTS `con_record`;
CREATE TABLE `con_record` (
  `cr_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `con_id` bigint(20) DEFAULT NULL,
  `result` int(10) DEFAULT NULL COMMENT '咨询、旷约、请假、脱落、结案，0，1，2，3，4，5五种状态',
  `content` varchar(255) DEFAULT NULL COMMENT '每次咨询内容，可为空',
  PRIMARY KEY (`cr_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10123465 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of con_record
-- ----------------------------
INSERT INTO `con_record` VALUES ('10123456', '10123456', '0', 'sss');
INSERT INTO `con_record` VALUES ('10123457', '10123457', '1', 'aaa');
INSERT INTO `con_record` VALUES ('10123458', '10123458', '2', 'bbb');
INSERT INTO `con_record` VALUES ('10123459', '10123459', '3', 'ccc');
INSERT INTO `con_record` VALUES ('10123460', '1011112', '3', 'eqwrewr');
INSERT INTO `con_record` VALUES ('10123461', '1011112', '5', '12321');
INSERT INTO `con_record` VALUES ('10123462', '10888889', '1', 'reqre');
INSERT INTO `con_record` VALUES ('10123463', '10888889', '5', '12323');
INSERT INTO `con_record` VALUES ('10123464', '10888890', '5', null);

-- ----------------------------
-- Table structure for duty
-- ----------------------------
DROP TABLE IF EXISTS `duty`;
CREATE TABLE `duty` (
  `d_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `u_id` bigint(20) DEFAULT NULL,
  `u_name` varchar(255) DEFAULT NULL,
  `type` int(10) DEFAULT NULL COMMENT '表示不同权限',
  `date` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL COMMENT '时间间隔固定为2h',
  `state` tinyint(1) DEFAULT NULL COMMENT '空闲状态，初始为0，绑定学生后置为1。\r\n咨询师：当且仅当结案时，由1置为0；\r\n初访员：当且仅当初访结束后，由1置为0。\r\n查询此字段需要根据type字段',
  PRIMARY KEY (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of duty
-- ----------------------------
INSERT INTO `duty` VALUES ('1', '20204563', '小三', '3', '周五', '14:00-16:00', '0');
INSERT INTO `duty` VALUES ('2', '20204567', '小八', '2', '周四', '16:00-18:00', '0');
INSERT INTO `duty` VALUES ('3', '20204568', '小狗', '2', '周四', '10:00-12:00', '0');
INSERT INTO `duty` VALUES ('4', '20204569', '张三', '2', '周三', '16:00-18:00', '0');
INSERT INTO `duty` VALUES ('5', '20204567', '小八', '2', '周三', '16:00-18:00', '0');
INSERT INTO `duty` VALUES ('12', '20204567', '小八', '2', '周一', '8:00-10:00', '0');
INSERT INTO `duty` VALUES ('13', '20207777', '校历', '2', '周一', '8:00-10:00', '1');

-- ----------------------------
-- Table structure for interview
-- ----------------------------
DROP TABLE IF EXISTS `interview`;
CREATE TABLE `interview` (
  `i_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stu_id` bigint(20) DEFAULT NULL,
  `inter_id` bigint(20) DEFAULT NULL COMMENT '由中心管理员确定的最终初访员',
  `state` varchar(255) DEFAULT NULL COMMENT '表示该学生是否被初访过，已经初访则置为1，否则为0',
  `pro_level` varchar(255) DEFAULT NULL,
  `pro_type` varchar(255) DEFAULT NULL,
  `summary` bigint(10) DEFAULT NULL COMMENT '初访结论，0，1，2三个状态，当且仅当为1的时候可以进入下一阶段',
  `date` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `logic` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`i_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of interview
-- ----------------------------
INSERT INTO `interview` VALUES ('1', '10963356', '10632496', '1', 'aaa', 'ddd', '0', '周五', '17:00-19:00', '0');
INSERT INTO `interview` VALUES ('2', '10999956', '10632459', '1', 'aaa', 'bbb', '1', '周五', '18:00-19:00', '1');
INSERT INTO `interview` VALUES ('3', '123456', '20204567', '1', 'bbb', '问题非常大', '1', '周三', '16:00-18:00', '1');
INSERT INTO `interview` VALUES ('4', '123456', '20204567', '1', 'hhh', 'hhhh', '1', '周四', '16:00-18:00', '1');
INSERT INTO `interview` VALUES ('5', '12345', '20204568', '1', 'hhh', 'hhhh', '1', '周四', '10:00-12:00', '0');
INSERT INTO `interview` VALUES ('7', '20201415', '20204563', '0', null, null, null, '周五', '14:00-16:00', '0');
INSERT INTO `interview` VALUES ('8', '20201181', '20204567', '1', '111', '222', '1', '周一', '8:00-10:00', '1');

-- ----------------------------
-- Table structure for question
-- ----------------------------
DROP TABLE IF EXISTS `question`;
CREATE TABLE `question` (
  `q_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contend` varchar(255) NOT NULL COMMENT '由后台设置的每个问题的内容',
  `score` bigint(20) NOT NULL COMMENT '每个问题的得分',
  PRIMARY KEY (`q_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10149542 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of question
-- ----------------------------
INSERT INTO `question` VALUES ('1', '我是大帅哥', '100');
INSERT INTO `question` VALUES ('2', 'aaa', '9');
INSERT INTO `question` VALUES ('3', 'qfg', '5');
INSERT INTO `question` VALUES ('4', 'qqw', '4');
INSERT INTO `question` VALUES ('5', 'www', '3');
INSERT INTO `question` VALUES ('6', 'eee', '10');
INSERT INTO `question` VALUES ('7', 'we', '4');
INSERT INTO `question` VALUES ('8', 'qw', '1');
INSERT INTO `question` VALUES ('9', 'fg', '2');
INSERT INTO `question` VALUES ('10', 'wuhuhhu', '5');

-- ----------------------------
-- Table structure for report
-- ----------------------------
DROP TABLE IF EXISTS `report`;
CREATE TABLE `report` (
  `r_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `con_id` bigint(20) DEFAULT NULL,
  `stu_id` bigint(255) DEFAULT NULL,
  `stu_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dept` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pro_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nums` bigint(20) DEFAULT NULL,
  `remark` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `t_id` bigint(20) DEFAULT NULL,
  `t_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of report
-- ----------------------------
INSERT INTO `report` VALUES ('1', '111', '111', '111', '111', '111', '111', null, '111', '111', '111', '111');
INSERT INTO `report` VALUES ('2', '222', '222', '222', '222', '222', '222', '222', '222', '222', '222', '222');
INSERT INTO `report` VALUES ('3', '1011112', '10227722', 'asd', null, 'rqewqw', 'rqe', '2', 'rwere', null, '20201415', 'jkhjk');
INSERT INTO `report` VALUES ('4', '10888890', '20201181', '111', '123654', 'fdasfsdfsad', 'sdfa', '1', 'fsdfa', '111', '20204563', '王八');
INSERT INTO `report` VALUES ('7', '10888889', '123456', null, null, 'eqweq', '3331', '2', 'eqweq', '南', '20204563', null);

-- ----------------------------
-- Table structure for reservation
-- ----------------------------
DROP TABLE IF EXISTS `reservation`;
CREATE TABLE `reservation` (
  `r_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stu_id` bigint(20) DEFAULT NULL,
  `inter_id` bigint(20) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `stu_name` varchar(255) DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL,
  `scores` bigint(20) DEFAULT NULL,
  `q1` tinyint(4) DEFAULT NULL,
  `q2` tinyint(4) DEFAULT NULL,
  `q3` tinyint(4) DEFAULT NULL,
  `q4` tinyint(4) DEFAULT NULL,
  `q5` tinyint(4) DEFAULT NULL,
  `q6` tinyint(4) DEFAULT NULL,
  `q7` tinyint(4) DEFAULT NULL,
  `q8` tinyint(4) DEFAULT NULL,
  `q9` tinyint(4) DEFAULT NULL,
  `q10` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of reservation
-- ----------------------------
INSERT INTO `reservation` VALUES ('1', '10996556', '10659278', '周一', '10:00-12:00', '王四', '1', '25', '1', '0', '1', '0', '1', '0', '1', '0', '1', '0');
INSERT INTO `reservation` VALUES ('2', '10914756', '10663278', '周二', '12:00-14:00', '赵三', '1', '32', '1', '1', '1', '0', '0', '1', '1', '0', '1', '0');
INSERT INTO `reservation` VALUES ('3', '10987456', '10695478', '周三', '15:00-17:00', '李二', '0', '34', '1', '1', '0', '1', '0', '1', '0', '1', '1', '1');
INSERT INTO `reservation` VALUES ('4', '10945656', '10641578', '周四', '17:00-19:00', '帅哥', '0', '56', '1', '1', '1', '0', '1', '1', '0', '1', '0', '1');
INSERT INTO `reservation` VALUES ('5', '12345', '34567', '周三', '14:00-16:00', '小帅', '1', '57', '1', '0', '1', '1', '0', '1', '0', '1', '0', '1');
INSERT INTO `reservation` VALUES ('6', '123456', '34567', '周三', '14:00-16:00', '小王', '0', '99', '1', '1', '1', '0', '1', '0', '1', '1', '0', '1');
INSERT INTO `reservation` VALUES ('7', '20201415', '34567', '周五', '14:00-16:00', '小帅', '1', '97', '1', '0', '1', '0', '1', '1', '0', '1', '0', '1');
INSERT INTO `reservation` VALUES ('18', '20201181', '20204567', '周一', '8:00-10:00', '111', '1', '8', '0', '0', '0', '0', '0', '0', '0', '1', '1', '1');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `u_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `u_name` varchar(255) DEFAULT NULL,
  `type` bigint(10) DEFAULT NULL COMMENT '表示不同权限',
  `sex` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL COMMENT '个人介绍',
  `photo` varchar(255) DEFAULT NULL COMMENT '存放图片的url',
  `state` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`u_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1673894115231690756 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('123456', '哈哈哈', '1', '南', null, null, '111', null, null, '1');
INSERT INTO `user` VALUES ('20201181', '111', '1', '111', '147369@qq.com', '123654', '1111', '111', null, '1');
INSERT INTO `user` VALUES ('20201414', 'xxx', '5', '男', '123456@qq.com', '1212121', '123456', '备注哇哇哇哇', '123', '1');
INSERT INTO `user` VALUES ('20201415', 'zm', '3', '女', '1400557884@qq.com', '19180962124', '456789', 'shabi', '556', '0');
INSERT INTO `user` VALUES ('20201416', 'qqs', '2', '女', '495631@qq.com', '459631', '741256', '无', '566', '1');
INSERT INTO `user` VALUES ('20201417', 'ddl', '4', null, '123', '1234', '123456', 'xx', null, '0');
INSERT INTO `user` VALUES ('20204563', '王八', '3', '南', null, null, '111', null, null, '1');
INSERT INTO `user` VALUES ('20204567', '小八', '2', '南', null, '19180962124', '123456', null, null, '1');
